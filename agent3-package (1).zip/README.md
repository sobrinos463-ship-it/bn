# Agent3 Console + Real Runner (n8n)

## Contenido
- `agent3-console/` – App web + proxy (`/agent3`) para hablar con n8n sin CORS
  - `server.js`
  - `public/index.html`
- `agent3-console.service` – Unit de systemd (edita si quieres)
- `agent3-real-runner-n8n.json` – Workflow importable para n8n (runner real)

## Deploy rápido (Debian)
```bash
sudo apt update && sudo apt install -y nodejs npm
sudo mkdir -p /opt/agent3-console && sudo chown $USER:$USER /opt/agent3-console
cp -r agent3-console/* /opt/agent3-console/
cd /opt/agent3-console && npm init -y && npm i express cors node-fetch@2

sudo cp agent3-console.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now agent3-console
```
Abre en el navegador `http://IP:8080` y usa `/agent3` como URL.

## Importar workflow
En n8n → Import → `agent3-real-runner-n8n.json`.
Asegura `OPENAI_API_KEY` en los nodos HTTP.
