const express = require("express");
const fetch = require("node-fetch");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 8080;
const N8N_URL = process.env.N8N_AGENT3_URL || "http://95.170.13.74:5660/webhook/agent3";

app.use(cors());
app.use(express.json({ limit: "15mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/agent3", async (req, res) => {
  try {
    const r = await fetch(N8N_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req.body)
    });
    const data = await r.json().catch(()=> ({}));
    res.status(r.status).json(data);
  } catch (e) {
    res.status(500).json({ ok:false, error: String(e) });
  }
});

app.listen(PORT, () => console.log(`Agent3 console on http://0.0.0.0:${PORT}`));
